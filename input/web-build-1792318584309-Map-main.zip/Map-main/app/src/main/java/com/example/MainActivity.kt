package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import com.example.data.model.Marker
import com.example.data.repository.MarkerRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.attemptAutoSignIn
import com.example.ui.auth.signOutUser
import com.example.ui.dialogs.AddMarkerDialog
import com.example.ui.map.MapScreen
import com.example.ui.moderation.ModerationScreen
import com.example.ui.mymarkers.MyMarkersScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.theme.MapMarksTheme
import com.example.util.ModeratorUtils
import com.google.android.gms.location.LocationServices
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MapMarksTheme {
                AppContent()
            }
        }
    }
}

@Composable
fun AppContent() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var currentUser by remember { mutableStateOf<FirebaseUser?>(Firebase.auth.currentUser) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    // Auto-sign in on initial launch if credentials available
    LaunchedEffect(Unit) {
        val credentialManager = CredentialManager.create(context)
        attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = { currentUser = Firebase.auth.currentUser },
            onUnauthenticated = { /* user signs in interactively */ },
            scope = coroutineScope
        )
    }

    if (currentUser == null) {
        AuthScreen(
            onAuthSuccess = { currentUser = Firebase.auth.currentUser }
        )
    } else {
        MainAuthenticatedApp(
            user = currentUser!!,
            onSignOut = {
                val credentialManager = CredentialManager.create(context)
                signOutUser(
                    context = context,
                    credentialManager = credentialManager,
                    onSignOutComplete = { currentUser = null },
                    scope = coroutineScope
                )
            }
        )
    }
}

@SuppressLint("MissingPermission")
@Composable
fun MainAuthenticatedApp(
    user: FirebaseUser,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val repository = remember(user.uid) { MarkerRepository(context) }
    val isModerator = remember(user.email) { ModeratorUtils.isModerator(user.email) }

    // Realtime streams
    val approvedMarkers by repository.observeApprovedMarkers().collectAsState(initial = emptyList())
    val userMarkers by repository.observeUserMarkers(user.uid).collectAsState(initial = emptyList())
    val pendingMarkers by if (isModerator) {
        repository.observePendingMarkers().collectAsState(initial = emptyList())
    } else {
        emptyFlow<List<Marker>>().collectAsState(initial = emptyList())
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var showAddDialog by remember { mutableStateOf(false) }
    var addInitialCoords by remember { mutableStateOf(Pair(50.4501, 30.5234)) }
    var isSubmittingMarker by remember { mutableStateOf(false) }
    var userLocation by remember { mutableStateOf<Pair<Double, Double>?>(null) }

    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            try {
                fusedLocationClient.lastLocation.addOnSuccessListener { loc ->
                    if (loc != null) {
                        userLocation = Pair(loc.latitude, loc.longitude)
                        Toast.makeText(context, "Локацію визначено", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: SecurityException) {
                // permission revoked
            }
        } else {
            Toast.makeText(context, "Доступ до геолокації відхилено", Toast.LENGTH_SHORT).show()
        }
    }

    val requestLocationAction: () -> Unit = {
        val hasFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (hasFine || hasCoarse) {
            try {
                fusedLocationClient.lastLocation.addOnSuccessListener { loc ->
                    if (loc != null) {
                        userLocation = Pair(loc.latitude, loc.longitude)
                        addInitialCoords = Pair(loc.latitude, loc.longitude)
                    }
                }
            } catch (e: SecurityException) {
                // Ignore
            }
        } else {
            locationPermissionLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(modifier = Modifier.testTag("main_bottom_nav")) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Map, contentDescription = "Карта") },
                    label = { Text("Карта") },
                    modifier = Modifier.testTag("nav_tab_map")
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Bookmark, contentDescription = "Мої мітки") },
                    label = { Text("Мої мітки") },
                    modifier = Modifier.testTag("nav_tab_mymarkers")
                )
                if (isModerator) {
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = {
                            if (pendingMarkers.isNotEmpty()) {
                                BadgedBox(badge = { Badge { Text("${pendingMarkers.size}") } }) {
                                    Icon(Icons.Default.Shield, contentDescription = "Модерація")
                                }
                            } else {
                                Icon(Icons.Default.Shield, contentDescription = "Модерація")
                            }
                        },
                        label = { Text("Модерація") },
                        modifier = Modifier.testTag("nav_tab_moderation")
                    )
                }
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Person, contentDescription = "Профіль") },
                    label = { Text("Профіль") },
                    modifier = Modifier.testTag("nav_tab_profile")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> MapScreen(
                    markers = approvedMarkers,
                    userLocation = userLocation,
                    onRequestLocation = requestLocationAction,
                    onAddMarkerClick = { lat, lng ->
                        addInitialCoords = Pair(lat, lng)
                        showAddDialog = true
                    },
                    isModerator = isModerator,
                    onDeleteMarker = { markerId ->
                        coroutineScope.launch {
                            repository.deleteMarker(markerId)
                            snackbarHostState.showSnackbar("Мітку видалено")
                        }
                    }
                )
                1 -> MyMarkersScreen(
                    userMarkers = userMarkers,
                    onAddNewMarkerClick = {
                        showAddDialog = true
                    },
                    onDeleteMarker = { markerId ->
                        coroutineScope.launch {
                            repository.deleteMarker(markerId)
                            snackbarHostState.showSnackbar("Мітку видалено")
                        }
                    }
                )
                2 -> ModerationScreen(
                    isModerator = isModerator,
                    currentUserEmail = user.email,
                    pendingMarkers = pendingMarkers,
                    onApproveMarker = { markerId, note ->
                        coroutineScope.launch {
                            val res = repository.approveMarker(markerId, user.uid, note)
                            if (res.isSuccess) {
                                snackbarHostState.showSnackbar("Мітку схвалено! Тепер її видно всім.")
                            } else {
                                snackbarHostState.showSnackbar("Помилка схвалення")
                            }
                        }
                    },
                    onRejectMarker = { markerId, note ->
                        coroutineScope.launch {
                            val res = repository.rejectMarker(markerId, user.uid, note)
                            if (res.isSuccess) {
                                snackbarHostState.showSnackbar("Мітку відхилено")
                            } else {
                                snackbarHostState.showSnackbar("Помилка відхилення")
                            }
                        }
                    },
                    onDeleteMarker = { markerId ->
                        coroutineScope.launch {
                            repository.deleteMarker(markerId)
                            snackbarHostState.showSnackbar("Мітку видалено модератором")
                        }
                    }
                )
                3 -> ProfileScreen(
                    user = user,
                    isModerator = isModerator,
                    onSignOut = onSignOut
                )
            }

            if (showAddDialog) {
                AddMarkerDialog(
                    initialLat = addInitialCoords.first,
                    initialLng = addInitialCoords.second,
                    onDismiss = { showAddDialog = false },
                    onUseCurrentLocation = requestLocationAction,
                    isSubmitting = isSubmittingMarker,
                    onSubmit = { title, description, category, lat, lng ->
                        isSubmittingMarker = true
                        coroutineScope.launch {
                            val result = repository.createMarker(
                                title = title,
                                description = description,
                                category = category,
                                latitude = lat,
                                longitude = lng,
                                authorName = user.displayName ?: "Користувач",
                                authorEmail = user.email ?: ""
                            )
                            isSubmittingMarker = false
                            showAddDialog = false
                            if (result.isSuccess) {
                                snackbarHostState.showSnackbar(
                                    "Мітку надіслано на модерацію! Після схвалення вона з'явиться на карті."
                                )
                            } else {
                                snackbarHostState.showSnackbar(
                                    "Помилка створення: ${result.exceptionOrNull()?.localizedMessage}"
                                )
                            }
                        }
                    }
                )
            }
        }
    }
}
