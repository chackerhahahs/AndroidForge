package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class MarkerCategory(
    val id: String,
    val titleUk: String,
    val colorHex: String,
    val iconName: String
) {
    ATTRACTION("attraction", "Визначне місце", "#8B5CF6", "place"),
    FOOD("food", "Їжа та кафе", "#F59E0B", "restaurant"),
    VIEWPOINT("viewpoint", "Оглядовий майданчик", "#10B981", "landscape"),
    PARK("park", "Парк / Природа", "#06B6D4", "forest"),
    DANGER("danger", "Увага / Небезпека", "#EF4444", "warning"),
    OTHER("other", "Інше", "#3B82F6", "bookmark");

    companion object {
        fun fromId(id: String): MarkerCategory {
            return entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: OTHER
        }
    }
}

enum class MarkerStatus(val value: String, val titleUk: String) {
    PENDING("pending", "На розгляді"),
    APPROVED("approved", "Схвалено"),
    REJECTED("rejected", "Відхилено");

    companion object {
        fun fromValue(value: String): MarkerStatus {
            return entries.firstOrNull { it.value.equals(value, ignoreCase = true) } ?: PENDING
        }
    }
}

@IgnoreExtraProperties
data class Marker(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    val category: String = "other",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val userId: String = "",
    val authorName: String = "",
    val authorEmail: String = "",
    val status: String = "pending",
    val reviewNote: String = "",
    val reviewedBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val categoryEnum: MarkerCategory
        get() = MarkerCategory.fromId(category)

    val statusEnum: MarkerStatus
        get() = MarkerStatus.fromValue(status)
}
