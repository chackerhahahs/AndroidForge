package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.Marker
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class MarkerRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        Firebase.auth
    )

    private val markersCollection = db.collection("markers")

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before performing database operations.")
    }

    /**
     * Observe all approved markers visible to every user.
     */
    fun observeApprovedMarkers(): Flow<List<Marker>> {
        val path = "markers(status=approved)"
        return markersCollection
            .whereEqualTo("status", "approved")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Marker::class.java)
            }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                throw e
            }
    }

    /**
     * Observe markers created by a specific user.
     */
    fun observeUserMarkers(userId: String): Flow<List<Marker>> {
        val path = "markers(userId=$userId)"
        return markersCollection
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Marker::class.java)
            }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                throw e
            }
    }

    /**
     * Observe markers pending moderation (accessible to authorized moderators).
     */
    fun observePendingMarkers(): Flow<List<Marker>> {
        val path = "markers(status=pending)"
        return markersCollection
            .whereEqualTo("status", "pending")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Marker::class.java)
            }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                throw e
            }
    }

    /**
     * Create a new marker submitted for moderation.
     */
    suspend fun createMarker(
        title: String,
        description: String,
        category: String,
        latitude: Double,
        longitude: Double,
        authorName: String,
        authorEmail: String
    ): Result<String> {
        return try {
            val uid = requireUserId()
            val payload = mapOf(
                "title" to title.trim(),
                "description" to description.trim(),
                "category" to category,
                "latitude" to latitude,
                "longitude" to longitude,
                "userId" to uid,
                "authorName" to authorName.trim(),
                "authorEmail" to authorEmail.trim(),
                "status" to "pending",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            val docRef = markersCollection.add(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "markers")
            Result.failure(e)
        }
    }

    /**
     * Approve marker by moderator.
     */
    suspend fun approveMarker(markerId: String, reviewerId: String, note: String = ""): Result<Unit> {
        val docRef = markersCollection.document(markerId)
        return try {
            val updates = mapOf(
                "status" to "approved",
                "reviewedBy" to reviewerId,
                "reviewNote" to note.trim(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    /**
     * Reject marker by moderator with reason.
     */
    suspend fun rejectMarker(markerId: String, reviewerId: String, note: String): Result<Unit> {
        val docRef = markersCollection.document(markerId)
        return try {
            val updates = mapOf(
                "status" to "rejected",
                "reviewedBy" to reviewerId,
                "reviewNote" to note.trim(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    /**
     * Delete marker (by author or moderator).
     */
    suspend fun deleteMarker(markerId: String): Result<Unit> {
        val docRef = markersCollection.document(markerId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }
}
