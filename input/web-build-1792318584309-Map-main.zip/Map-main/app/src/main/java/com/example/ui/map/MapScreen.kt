package com.example.ui.map

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.model.Marker
import com.example.data.model.MarkerCategory
import org.json.JSONArray
import org.json.JSONObject

class MapWebBridge(
    private val onMapClick: (Double, Double) -> Unit,
    private val onMarkerClick: (String) -> Unit,
    private val onReady: () -> Unit
) {
    @JavascriptInterface
    fun onMapClicked(lat: Double, lng: Double) {
        onMapClick(lat, lng)
    }

    @JavascriptInterface
    fun onMarkerClicked(markerId: String) {
        onMarkerClick(markerId)
    }

    @JavascriptInterface
    fun onMapReady() {
        onReady()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    markers: List<Marker>,
    userLocation: Pair<Double, Double>?,
    onRequestLocation: () -> Unit,
    onAddMarkerClick: (lat: Double, lng: Double) -> Unit,
    isModerator: Boolean,
    onDeleteMarker: (String) -> Unit
) {
    val context = LocalContext.current
    var isListView by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf<MarkerCategory?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedMarker by remember { mutableStateOf<Marker?>(null) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var isMapReady by remember { mutableStateOf(false) }
    var currentMapCenter by remember { mutableStateOf(Pair(50.4501, 30.5234)) }

    // Filter markers
    val filteredMarkers = remember(markers, selectedCategory, searchQuery) {
        markers.filter { marker ->
            val matchesCategory = selectedCategory == null || marker.category.equals(selectedCategory!!.id, ignoreCase = true)
            val matchesSearch = searchQuery.isBlank() ||
                    marker.title.contains(searchQuery, ignoreCase = true) ||
                    marker.description.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    // Update WebView when markers change or map is ready
    LaunchedEffect(filteredMarkers, isMapReady) {
        if (isMapReady && webViewRef != null) {
            val jsonArray = JSONArray()
            filteredMarkers.forEach { m ->
                val obj = JSONObject().apply {
                    put("id", m.id)
                    put("title", m.title)
                    put("category", m.category)
                    put("colorHex", m.categoryEnum.colorHex)
                    put("latitude", m.latitude)
                    put("longitude", m.longitude)
                }
                jsonArray.put(obj)
            }
            val escapedJson = jsonArray.toString().replace("'", "\\'")
            webViewRef?.evaluateJavascript("setMarkers('$escapedJson');", null)
        }
    }

    // Update user location on map
    LaunchedEffect(userLocation, isMapReady) {
        if (userLocation != null && isMapReady && webViewRef != null) {
            webViewRef?.evaluateJavascript("setUserLocation(${userLocation.first}, ${userLocation.second});", null)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (isListView) {
            // List View
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(top = 8.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (filteredMarkers.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Не знайдено міток за вибраними фільтрами",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        items(filteredMarkers, key = { it.id }) { marker ->
                            MarkerListCard(
                                marker = marker,
                                onClick = {
                                    selectedMarker = marker
                                }
                            )
                        }
                    }
                }
            }
        } else {
            // Interactive Map View
            AndroidView(
                factory = { ctx ->
                    createConfiguredWebView(
                        context = ctx,
                        onMapClick = { lat, lng ->
                            currentMapCenter = Pair(lat, lng)
                        },
                        onMarkerClick = { markerId ->
                            selectedMarker = markers.firstOrNull { it.id == markerId }
                        },
                        onReady = {
                            isMapReady = true
                        }
                    ).also { webViewRef = it }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Top Filter & Search Bar
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.95f))
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Пошук міток...") },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Очистити")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.weight(1f)
                )

                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier
                        .size(48.dp)
                        .clickable { isListView = !isListView }
                        .testTag("toggle_map_list_view_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isListView) Icons.Default.Map else Icons.Default.ViewList,
                            contentDescription = if (isListView) "Показати карту" else "Показати список",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            // Category Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CategoryChip(
                    title = "Всі (${markers.size})",
                    colorHex = "#2563EB",
                    isSelected = selectedCategory == null,
                    onClick = { selectedCategory = null }
                )
                MarkerCategory.entries.forEach { cat ->
                    val count = markers.count { it.category.equals(cat.id, ignoreCase = true) }
                    CategoryChip(
                        title = "${cat.titleUk} ($count)",
                        colorHex = cat.colorHex,
                        isSelected = selectedCategory == cat,
                        onClick = { selectedCategory = if (selectedCategory == cat) null else cat }
                    )
                }
            }
        }

        // Floating Action Buttons (Right Bottom)
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.End
        ) {
            FloatingActionButton(
                onClick = onRequestLocation,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("my_location_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.MyLocation,
                    contentDescription = "Моя локація"
                )
            }

            ExtendedFloatingActionButton(
                onClick = {
                    onAddMarkerClick(currentMapCenter.first, currentMapCenter.second)
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_marker_fab")
            ) {
                Icon(Icons.Default.AddLocationAlt, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Додати мітку", fontWeight = FontWeight.SemiBold)
            }
        }

        // Marker Detail Sheet
        if (selectedMarker != null) {
            MarkerDetailBottomSheet(
                marker = selectedMarker!!,
                onDismiss = { selectedMarker = null },
                isModerator = isModerator,
                onDelete = {
                    onDeleteMarker(selectedMarker!!.id)
                    selectedMarker = null
                },
                onOpenInGoogleMaps = {
                    openGoogleMapsNavigation(context, selectedMarker!!.latitude, selectedMarker!!.longitude, selectedMarker!!.title)
                }
            )
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
private fun createConfiguredWebView(
    context: Context,
    onMapClick: (Double, Double) -> Unit,
    onMarkerClick: (String) -> Unit,
    onReady: () -> Unit
): WebView {
    return WebView(context).apply {
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = true
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        webViewClient = WebViewClient()
        webChromeClient = WebChromeClient()
        addJavascriptInterface(MapWebBridge(onMapClick, onMarkerClick, onReady), "AndroidBridge")
        loadUrl("file:///android_asset/map.html")
    }
}

@Composable
private fun CategoryChip(
    title: String,
    colorHex: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val color = Color(android.graphics.Color.parseColor(colorHex))
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) color.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, color) else null,
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(color, CircleShape)
            )
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun MarkerListCard(
    marker: Marker,
    onClick: () -> Unit
) {
    val catColor = Color(android.graphics.Color.parseColor(marker.categoryEnum.colorHex))
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(catColor.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Place,
                    contentDescription = null,
                    tint = catColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = marker.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = catColor.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = marker.categoryEnum.titleUk,
                            style = MaterialTheme.typography.labelSmall,
                            color = catColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = marker.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Автор: ${marker.authorName.ifBlank { "Анонімний" }} • ${String.format("%.4f, %.4f", marker.latitude, marker.longitude)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarkerDetailBottomSheet(
    marker: Marker,
    onDismiss: () -> Unit,
    isModerator: Boolean,
    onDelete: () -> Unit,
    onOpenInGoogleMaps: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState()
    val catColor = Color(android.graphics.Color.parseColor(marker.categoryEnum.colorHex))

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(catColor.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Place,
                        contentDescription = null,
                        tint = catColor,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = marker.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = catColor.copy(alpha = 0.2f),
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Text(
                            text = marker.categoryEnum.titleUk,
                            style = MaterialTheme.typography.labelMedium,
                            color = catColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Text(
                text = marker.description,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "📍 Координати: ${marker.latitude}, ${marker.longitude}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "👤 Автор: ${marker.authorName.ifBlank { "Користувач" }} (${marker.authorEmail.ifBlank { "email приховано" }})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Button(
                onClick = onOpenInGoogleMaps,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("open_in_google_maps_button"),
                shape = RoundedCornerShape(24.dp)
            ) {
                Icon(Icons.Default.Directions, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Маршрут у Google Maps", fontWeight = FontWeight.Bold)
            }

            if (isModerator) {
                Button(
                    onClick = onDelete,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Text("Видалити мітку (Модератор)")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

fun openGoogleMapsNavigation(context: Context, lat: Double, lng: Double, label: String) {
    try {
        val gmmIntentUri = Uri.parse("geo:$lat,$lng?q=$lat,$lng(${Uri.encode(label)})")
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
            setPackage("com.google.android.apps.maps")
        }
        if (mapIntent.resolveActivity(context.packageManager) != null) {
            context.startActivity(mapIntent)
        } else {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lng"))
            context.startActivity(webIntent)
        }
    } catch (e: Exception) {
        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lng"))
        context.startActivity(webIntent)
    }
}
