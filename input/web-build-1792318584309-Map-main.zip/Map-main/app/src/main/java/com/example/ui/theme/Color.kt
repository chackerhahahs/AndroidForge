package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val IndigoPrimary = Color(0xFF2563EB)
val IndigoOnPrimary = Color(0xFFFFFFFF)
val IndigoPrimaryContainer = Color(0xFFDBEAFE)
val IndigoOnPrimaryContainer = Color(0xFF1E3A8A)

val TealSecondary = Color(0xFF0D9488)
val TealOnSecondary = Color(0xFFFFFFFF)
val TealSecondaryContainer = Color(0xFFCCFBF1)
val TealOnSecondaryContainer = Color(0xFF115E59)

val AmberTertiary = Color(0xFFD97706)
val AmberOnTertiary = Color(0xFFFFFFFF)
val AmberTertiaryContainer = Color(0xFFFEF3C7)
val AmberOnTertiaryContainer = Color(0xFF78350F)

val NeutralSurfaceLight = Color(0xFFF8FAFC)
val NeutralOnSurfaceLight = Color(0xFF0F172A)
val NeutralSurfaceVariantLight = Color(0xFFF1F5F9)
val NeutralOnSurfaceVariantLight = Color(0xFF475569)

val NeutralSurfaceDark = Color(0xFF0B1120)
val NeutralOnSurfaceDark = Color(0xFFF1F5F9)
val NeutralSurfaceVariantDark = Color(0xFF1E293B)
val NeutralOnSurfaceVariantDark = Color(0xFF94A3B8)
