package com.example.util

object ModeratorUtils {
    val MODERATOR_EMAILS = setOf(
        "daniilslonec2000@gmail.com",
        "tancikozenden@gmail.com",
        "pochkahop@gmail.com"
    )

    fun isModerator(email: String?): Boolean {
        if (email.isNullOrBlank()) return false
        val cleanEmail = email.trim().lowercase()
        return MODERATOR_EMAILS.any { it.lowercase() == cleanEmail }
    }
}
