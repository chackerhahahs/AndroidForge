package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MarkerRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createMarker_whenSignedIn_createsPendingMarker() = runBlocking {
        val email = "author_${System.currentTimeMillis()}@example.com"
        val uid = signInTestUser(email)
        val repository = MarkerRepository(firestore, auth)

        val result = repository.createMarker(
            title = "Test Landmark",
            description = "A wonderful place in Ukraine",
            category = "attraction",
            latitude = 50.4501,
            longitude = 30.5234,
            authorName = "Author User",
            authorEmail = email
        )

        assertTrue("Marker creation should succeed", result.isSuccess)
        val markerId = result.getOrNull()
        assertNotNull(markerId)

        val userMarkers = repository.observeUserMarkers(uid).first()
        assertTrue("User markers should not be empty", userMarkers.isNotEmpty())
        assertTrue("Should contain created marker", userMarkers.any { it.title == "Test Landmark" })
    }

    @Test
    fun deleteMarker_byAuthor_succeeds() = runBlocking {
        val email = "author_del_${System.currentTimeMillis()}@example.com"
        val uid = signInTestUser(email)
        val repository = MarkerRepository(firestore, auth)

        val createResult = repository.createMarker(
            title = "To be deleted",
            description = "Temp marker",
            category = "park",
            latitude = 49.8397,
            longitude = 24.0297,
            authorName = "Author Del",
            authorEmail = email
        )
        val markerId = createResult.getOrThrow()

        val deleteResult = repository.deleteMarker(markerId)
        assertTrue("Delete marker should succeed", deleteResult.isSuccess)
    }
}
