const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = "demo-no-project";

before(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules: fs.readFileSync("firestore.rules", "utf8"),
      host: "127.0.0.1",
      port: 8085,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot create a marker", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthDb.collection("markers").doc("marker1").set({
      title: "Test place",
      description: "Nice place",
      category: "attraction",
      latitude: 50.4501,
      longitude: 30.5234,
      userId: "user123",
      status: "pending",
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );
});

test("Authenticated user can create a pending marker for themselves", async () => {
  const authDb = testEnv.authenticatedContext("user123", { email: "user@example.com" }).firestore();
  await assertSucceeds(
    authDb.collection("markers").doc("marker1").set({
      title: "Kyiv Golden Gate",
      description: "Historic gateway in ancient Kyiv",
      category: "attraction",
      latitude: 50.4488,
      longitude: 30.5133,
      userId: "user123",
      status: "pending",
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );
});

test("Authenticated user cannot create a pre-approved marker", async () => {
  const authDb = testEnv.authenticatedContext("user123", { email: "user@example.com" }).firestore();
  await assertFails(
    authDb.collection("markers").doc("marker1").set({
      title: "Kyiv Golden Gate",
      description: "Historic gateway in ancient Kyiv",
      category: "attraction",
      latitude: 50.4488,
      longitude: 30.5133,
      userId: "user123",
      status: "approved",
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );
});

test("Anyone can read approved markers", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("markers").doc("marker_approved").set({
      title: "Approved place",
      description: "Open to all",
      category: "park",
      latitude: 50.0,
      longitude: 30.0,
      userId: "user123",
      status: "approved",
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  });

  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertSucceeds(unauthDb.collection("markers").doc("marker_approved").get());
});

test("Regular user cannot read someone else's pending marker", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("markers").doc("marker_pending").set({
      title: "Pending place",
      description: "Under review",
      category: "park",
      latitude: 50.0,
      longitude: 30.0,
      userId: "user123",
      status: "pending",
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  });

  const otherUserDb = testEnv.authenticatedContext("user456", { email: "other@example.com" }).firestore();
  await assertFails(otherUserDb.collection("markers").doc("marker_pending").get());
});

test("Author can read their own pending marker", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("markers").doc("marker_pending").set({
      title: "Pending place",
      description: "Under review",
      category: "park",
      latitude: 50.0,
      longitude: 30.0,
      userId: "user123",
      status: "pending",
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  });

  const authorDb = testEnv.authenticatedContext("user123", { email: "user@example.com" }).firestore();
  await assertSucceeds(authorDb.collection("markers").doc("marker_pending").get());
});

test("Moderator (daniilslonec2000@gmail.com) can read and approve pending marker", async () => {
  const createdAt = new Date();
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("markers").doc("marker_to_review").set({
      title: "Place to review",
      description: "Please approve",
      category: "food",
      latitude: 50.1,
      longitude: 30.1,
      userId: "user123",
      status: "pending",
      createdAt: createdAt,
      updatedAt: createdAt,
    });
  });

  const modDb = testEnv.authenticatedContext("mod1", {
    email: "daniilslonec2000@gmail.com",
    email_verified: true,
  }).firestore();

  await assertSucceeds(modDb.collection("markers").doc("marker_to_review").get());
  await assertSucceeds(
    modDb.collection("markers").doc("marker_to_review").update({
      status: "approved",
      reviewedBy: "mod1",
      reviewNote: "Approved, looks great!",
      updatedAt: new Date(),
    })
  );
});

test("Non-moderator cannot approve a marker", async () => {
  const createdAt = new Date();
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("markers").doc("marker_to_hack").set({
      title: "Place to hack",
      description: "Please approve",
      category: "food",
      latitude: 50.1,
      longitude: 30.1,
      userId: "user123",
      status: "pending",
      createdAt: createdAt,
      updatedAt: createdAt,
    });
  });

  const normalUserDb = testEnv.authenticatedContext("hacker", {
    email: "hacker@example.com",
  }).firestore();

  await assertFails(
    normalUserDb.collection("markers").doc("marker_to_hack").update({
      status: "approved",
      reviewedBy: "hacker",
      updatedAt: new Date(),
    })
  );
});
